#include <stdlib.h>
#include <stdio.h>
#include <iostream>
using namespace std;

class Cliente{
	//ATRIBUTOS PRIVADOS
	private:
		long dni;
		string nombres;
		int edad;
		
	//METODOS PUBLICOS
	public:
		Cliente(); //CONSTRUCTOR
		//METODOS SETTERS
		void setDNI(long);
		void setNombres(string);
		void setEdad(int);

		
		//METODOS GETTERS
		long getDNI();
		string getNombres();
		int getEdad();

		//DEMAS METODOS
		void registrarCliente();
		void buscarCliente();
		void modificarCliente();
		int verificarDNI(long);
};

Cliente::Cliente(){	
}

//METODOS SETTERS
void Cliente::setDNI(long _dni){
	dni = _dni;
}

void Cliente::setNombres(string _nombres){
	nombres = _nombres;
}

void Cliente::setEdad(int _edad){
	edad = _edad;
}

//METODOS GETTERS
long Cliente::getDNI(){
	return dni;
}

string Cliente::getNombres(){
	return nombres;
}

int Cliente::getEdad(){
	return edad;
}

//DEMAS METODOS
void Cliente::registrarCliente(){
	string nombres;
	long dni;
	int edad;
	
	system("cls");
    cout << endl << "\t\t\t      SISTEMA BANCARIO" << endl << endl;
	cout << " REGISTRAR CLIENTE" << endl << endl;
	cout << " Ingrese numero de DNI: ";
	cin >> dni;
	setDNI(dni);
	
	cin.ignore();
	cout << " Ingrese nombres:       ";
	getline(cin,nombres);
	setNombres(nombres);
	
	cout << " Ingrese edad:          ";
	cin >> edad;
	setEdad(edad);
	
	cout << endl << "Cliente Registrado Correctamente! Presione una tecla para continuar..";
	getch();
}

void Cliente::buscarCliente(){
	system("cls");
	cout << endl << "\t\t\t      SISTEMA BANCARIO" << endl << endl;
	cout << " CLIENTES REGISTRADOS" << endl << endl;
	cout << " DNI: " << getDNI() << endl;
	cout << " Nombres: " << getNombres() << endl;
	cout << " Edad: " << getEdad() << endl;
	
	cout << endl << "Presione una tecla para continuar..";
	getch();
}

int Cliente::verificarDNI(long _dni){
	int encontro = 0;
	
	if (dni == _dni){
		encontro = 1;
	}
	return encontro;
}