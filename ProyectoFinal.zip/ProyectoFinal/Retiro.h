#include <stdlib.h>
#include <stdio.h>
#include <iostream>
using namespace std;

class Retiro{
	//ATRIBUTOS PRIVADOS
	private:
		long nCuenta;
		string cliente;
		int cantidad;
		int nip;
		
		
	//METODOS PUBLICOS
	public:
		Retiro(); //CONSTRUCTOR
		
		//METODOS SETTERS
		void setNCuenta(long);
		void setCliente(string);
		void setCantidad(int);
		void setNIP(int);

		//METODOS GETTERS
		long getNCuenta();
		string getCliente();
		int getCantidad();
		int getNIP();
		
		//DEMAS METODOS
		void Retirar();
		void mostrarRetiros();
		int comprobarRetiro(long);
};

//CONSTRUCTOR
Retiro::Retiro(){	
}


//METODOS SETTERS
void Retiro::setNCuenta(long _nCuenta){
	nCuenta = _nCuenta;
}

void Retiro::setCliente(string _cliente){
	cliente = _cliente;
}

void Retiro::setNIP(int _nip){
	nip = _nip;
}

void Retiro::setCantidad(int _cantidad){
	cantidad = _cantidad;
}


//METODOS GETTERS
long Retiro::getNCuenta(){
	return nCuenta;
}

string Retiro::getCliente(){
	return cliente;
}

int Retiro::getNIP(){
	return nip;
}

int Retiro::getCantidad(){
	return cantidad;
}

//DEMAS METODOS
void Retiro::Retirar(){
	int cant;
	
	cout << "Ingrese cantidad a retirar: ";
	cin >> cant;
	setCantidad(cant);
	
	cout << endl << "El retiro se ha realizado! Presione una tecla para continuar..";
	getchar();
}

void Retiro::mostrarRetiros(){
	system("cls");
	cout << endl << "\t\t\t      SISTEMA BANCARIO" << endl << endl;
	cout << " RETIROS REALIZADOS" << endl << endl;
	cout << " Numero de cuenta:    " << getNCuenta() << endl;
	cout << " Cliente:             " << getCliente() << endl;
	cout << " Cantidad depositada: " << getCantidad() << endl;
	
	cout << endl << "Presione una tecla para continuar..";
	getch();
}

int Retiro::comprobarRetiro(long _ncuenta){
	int encontro = 0;
	
	if (nCuenta == _ncuenta){
		encontro = 1;
	}
	return encontro;
}