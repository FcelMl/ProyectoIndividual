#include <stdlib.h>
#include <stdio.h>
#include <iostream>
using namespace std;

class Deposito{
	//ATRIBUTOS PRIVADOS
	private:
		long nCuenta;
		string cliente;
		int cantidad;
		
		
	//METODOS PUBLICOS
	public:
		Deposito(); //CONSTRUCTOR
		
		//METODOS SETTERS
		void setNCuenta(long);
		void setCliente(string);
		void setCantidad(int);

		//METODOS GETTERS
		long getNCuenta();
		string getCliente();
		int getCantidad();
		
		//DEMAS METODOS
		void Depositar();
		void mostrarDepositos();
		int comprobarDeposito(long);
};

//CONSTRUCTOR
Deposito::Deposito(){	
}


//METODOS SETTERS
void Deposito::setNCuenta(long _nCuenta){
	nCuenta = _nCuenta;
}

void Deposito::setCliente(string _cliente){
	cliente = _cliente;
}

void Deposito::setCantidad(int _cantidad){
	cantidad = _cantidad;
}


//METODOS GETTERS
long Deposito::getNCuenta(){
	return nCuenta;
}

string Deposito::getCliente(){
	return cliente;
}

int Deposito::getCantidad(){
	return cantidad;
}

//DEMAS METODOS
void Deposito::Depositar(){
	int cant;
	
	cout << "Ingrese cantidad a depositar: ";
	cin >> cant;
	setCantidad(cant);
	
	cout << endl << "El deposito se ha realizado! Presione una tecla para continuar..";
	getchar();
}

void Deposito::mostrarDepositos(){
	system("cls");
	cout << endl << "\t\t\t      SISTEMA BANCARIO" << endl << endl;
	cout << " DEPOSITOS REALIZADOS" << endl << endl;
	cout << " Numero de cuenta:    " << getNCuenta() << endl;
	cout << " Cliente:             " << getCliente() << endl;
	cout << " Cantidad depositada: " << getCantidad() << endl;
	
	cout << endl << "Presione una tecla para continuar..";
	getch();
}

int Deposito::comprobarDeposito(long _ncuenta){
	int encontro = 0;
	
	if (nCuenta == _ncuenta){
		encontro = 1;
	}
	return encontro;
}